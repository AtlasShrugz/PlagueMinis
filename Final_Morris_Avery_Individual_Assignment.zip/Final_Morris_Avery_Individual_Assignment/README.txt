Hi Professor Wang! Please check the comments on this submission. I sort of figured out GitHub, and so I will put the link both here,
and in the comments of this post so you can access it easier.

https://github.com/AtlasShrugz/PlagueMinis