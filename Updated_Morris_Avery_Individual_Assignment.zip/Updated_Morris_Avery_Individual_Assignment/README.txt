Hi Professor Wang! As you can see, I used the first rubric, considering I already liked the website I made for that, but I implemented CSS and a style sheet now!
I am pretty proud of where it's at so far, and I tried to make it responsive to the size of phone, medium screen, etc. I tried using GitHub pages, but the layout of the site confused me.
I signed up and everything, but uploading and downloading stuff from GitHub has always been a struggle for me for some reason.
So I will be submitting this in zip format, if you do want me to try again to upload it to GitHub, I don't mind at all, all I ask for is a bit of help in that case!
Thanks in advance, I hope you like the website.